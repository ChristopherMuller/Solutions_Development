﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ComicStoresSLDFA2.Startup))]
namespace ComicStoresSLDFA2
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
