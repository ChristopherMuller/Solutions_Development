﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(SLD_FA1.Startup))]
namespace SLD_FA1
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
